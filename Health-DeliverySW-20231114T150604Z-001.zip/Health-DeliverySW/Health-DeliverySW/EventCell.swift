//
//  EventCell.swift
//  CalendarExampleTutorial
//
//  Created by CallumHill on 2/5/21.
//

import UIKit

class EventCell: UITableViewCell
{
	@IBOutlet weak var eventLabel: UILabel!
}
