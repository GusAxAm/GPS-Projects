//
//  AddMenuViewController.swift
//  Health-DeliverySW
//
//  Created by Daniel Saldivar on 21/05/23.
//

import UIKit

class AddMenuViewController: UIViewController{

    @IBOutlet weak var GuardarInfo: UIButton!
    @IBOutlet weak var Correo: UILabel!
    @IBOutlet weak var AddCuentaButton: UIButton!
    
    var recibirCorreo: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
       

        // Do any additional setup after loading the view.
    }
    
   @IBAction func GuardarInfoButton(_ sender: UIButton) {
        let alertaI = UIAlertController(title: "Listo!", message: "La informacion se guardo correctamente", preferredStyle: .alert)
        let accionCancelarI = UIAlertAction(title: "Cancelar", style: .destructive)
        let accionAceptarI = UIAlertAction(title: "Aceptar", style: .default) { _ in
            print("Receta agregada correctamente")
        }
        
        alertaI.addAction(accionCancelarI)
        alertaI.addAction(accionAceptarI)
        
        present(alertaI,animated: true)
    }
    
    @IBAction func AddCuenta(_ sender: UIButton) {
        let alerta = UIAlertController(title: "Listo!", message: "La receta se agrego correctamente", preferredStyle: .alert)
        let accionCancelar = UIAlertAction(title: "Cancelar", style: .destructive)
        let accionAceptar = UIAlertAction(title: "Aceptar", style: .default) { _ in
            print("Receta agregada correctamente")
        }
        
        alerta.addAction(accionCancelar)
        alerta.addAction(accionAceptar)
        
        present(alerta,animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
