//
//  CreacionCuentaViewController.swift
//  Health-DeliverySW
//
//  Created by Daniel Saldivar on 09/05/23.
//

import UIKit
import Firebase

class CreacionCuentaViewController: UIViewController {
    
    @IBOutlet weak var CCorreoTextfield: UITextField!
    @IBOutlet weak var CContraseñaTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func CrearCuenta(_ sender: UIButton) {
        guard let correo = CCorreoTextfield.text else {return}
        guard let contra = CContraseñaTextField.text else {return}
        
        Auth.auth().createUser(withEmail: correo, password: contra) {firebaseResult, error in
            if let e = error {
                    print("error")
            }
            else{
                self.performSegue(withIdentifier: "Siguiente", sender: self)
            }
        }
    }
    
   

}
