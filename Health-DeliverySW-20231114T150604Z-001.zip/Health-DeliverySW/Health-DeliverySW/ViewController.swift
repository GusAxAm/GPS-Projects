//
//  ViewController.swift
//  Health-DeliverySW
//
//  C
//

import UIKit
import Firebase
import GoogleSignIn
class ViewController: UIViewController {

    @IBOutlet weak var CorreoTextField: UITextField!
    
    @IBOutlet weak var Google: UIButton!
    @IBOutlet weak var ContraseñaTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }

    @IBAction func LoginButton(_ sender: UIButton) {
        guard let correo = CorreoTextField.text else {return}
        guard let contra = ContraseñaTextField.text else {return}
        
        Auth.auth().signIn(withEmail: correo, password: contra) {firebaseResult, error in
            if let e = error {
                print("Error")
            }
            else  {
                //Regresar a la primera interfaz
                self.performSegue(withIdentifier: "Siguiente", sender: self)
            }
        }
    }
    
    
  /*  @IBAction func SignGoogle(_ sender: UIButton) {
        
        guard let clientID = FirebaseApp.app()?.options.clientID else { return }

        // Create Google Sign In configuration object.
        let config = GIDConfiguration(clientID: clientID)
        GIDSignIn.sharedInstance.configuration = config

        // Start the sign in flow!
        GIDSignIn.sharedInstance.signIn(withPresenting: self) { [unowned self] result, error in
          guard error == nil else {
             
          }

          guard let user = result?.user,
            let idToken = user.idToken?.tokenString
          else {
            // ...
          }

          let credential = GoogleAuthProvider.credential(withIDToken: idToken,
                                                         accessToken: user.accessToken.tokenString)

          // ...
        }
    }*/
}

