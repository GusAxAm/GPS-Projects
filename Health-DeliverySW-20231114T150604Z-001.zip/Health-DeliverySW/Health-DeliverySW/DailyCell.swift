//
//  DailyCell.swift
//  CalendarExampleTutorial
//
//  Created by CallumHill on 31/8/21.
//

import UIKit

class DailyCell: UITableViewCell
{
	@IBOutlet weak var time: UILabel!
	@IBOutlet weak var event1: UILabel!
	@IBOutlet weak var event2: UILabel!
	@IBOutlet weak var event3: UILabel!
	
}
