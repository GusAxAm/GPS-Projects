//
//  CalendarCell.swift
//  CalendarExampleTutorial
//
//  Created by CallumHill on 14/1/21.
//

import UIKit

class CalendarCell: UICollectionViewCell
{
	@IBOutlet weak var dayOfMonth: UILabel!
}
