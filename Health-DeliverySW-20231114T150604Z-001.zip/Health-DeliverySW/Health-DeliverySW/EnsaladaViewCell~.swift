//
//  EnsaladaViewCell.swift
//  Health-DeliverySW
//
//  Created by Daniel Saldivar on 21/05/23.
//

import UIKit

class EnsaladaViewCell UITableViewCell {

    @IBOutlet weak var backView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var profilePicImage: UIImageView!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
